<?php

class RegisterController extends Controller{

	public $postObject;



// blog/
	public function index(){

		//$this->postObject = new Users();
		//$posts = $this->postObject->addUser($data = '');
		$this->set('message', '');
		$this->set('fname', '');
		$this->set('lname', '');
		$this->set('email', '');
		$this->set('pass', '');
		$this->set('Title', '');

		//$this->set('posts',$posts);
		$this->set('task', 'add');
	}


	public function add(){
    $this->set('title','');
    $this->set('Title', 'The Register View');
    $this->set('fname',$_POST['first_name']);
    $this->set('lname', $_POST['last_name']);
		$this->set('email',$_POST['email']);
    $this->set('pass', $_POST['password']);

		$this->postObject = new Users();
		$pass = $_POST['password'];
		$passhash = PASSWORD_HASH($pass, PASSWORD_DEFAULT);

		$data = array(
      'fname' => $_POST['first_name'],
      'lname' => $_POST['last_name'],
      'email' => $_POST['email'],
      'pass' => $passhash
      );
			$result = $this->postObject->addUser($data);
			$this->set('message', $result);

	}

}
?>
