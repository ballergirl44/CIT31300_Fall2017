<?php


class Comments extends Model{

// update  =  save

  public function update($pID){
		$this->postObject = new Post();
		$post = $this->postObject->getPost($pID);
		//$this->getCategories();

		$this->set('pID', $post['pID']);
		$this->set('title', $post['title']);
		$this->set('content', $post['content']);
		$this->set('date', $post['date']);
		$this->set('category', $post['categoryID']);

		$this->set('task', 'update');

	}




public function delete(){

}


}
 ?>
