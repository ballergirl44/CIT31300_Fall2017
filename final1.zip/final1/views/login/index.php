<?php include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">

	 <?php

	 echo $_GET['cannot_access'];

	 ?>


	 <?php if(isset($error)){?>
		 <div class="alert alert-danger"><?php echo $error; ?></div>
		 <?php }; ?>

   <form id="login_form" action="<?php echo BASE_URL; ?>login/do_login" method="post">

<fieldset>
<legend>Login</legend>
<label for="username">Email Address <font color="#ffb6c1">*</font></label>
<input type="text" id="email" name="email" value="" maxlength="50" required="email" />
<br>

<label for="password">Password <font color="#ffb6c1">*</font></label>
<input type="password" class="txt" id="password" name="password" value="" maxlength="20" required="password" />
<br>

<br>

<button id="submit" type="submit" class="btn btn-primary" >Login</button>
</fieldset>
</form>
  </div>
</div>
<?php include('views/elements/footer.php');?>
