
<?php include('views/elements/header.php');?>
<?php
if( is_array($post) ) {
	extract($post);
}?>

<div class="container">
	<div class="page-header"><h1><?php echo $title;?></h1></div>

<?php echo $content;?>
<br>
<sub><?php echo 'Posted on ' . $date . ' by <a href="'.BASE_URL.'members/view/'. $uid.'">'. $first_name . ' ' . $last_name . '</a> in <a href="'.BASE_URL.'category/view/'. $categoryid.'">' . $name .'</a>'; ?>
</sub><br><br>

<?php
if($u->isAdmin()){
	?>
	<a href="http://corsair.cs.iupui.edu:21991/final/manageposts/edit/<?php echo $pid?>"><input type="submit" id="submitEdit" class="btn btn-secondary" value="Edit"></a>
	<a href="http://corsair.cs.iupui.edu:21991/final/manageposts/delete/<?php echo $pid?>"><input type="submit" id="submitEdit" class="btn btn-primary" value="Delete"></a>

<?php
	} // end of isAdmin method
?>

<div id="cmain"><br><br>
<br>

	<div class="well">
<h2>Comments</h2>
		<?php if(is_array($posts) ) {
			?>

		<div class="container">
		<div class="page-header">



			<?php foreach($posts as $p){
				?>

				<hr/>
				<?php
				if($u->isAdmin()){

					?>


				<a href="http://corsair.cs.iupui.edu:21991/final/comments/delete/<?php echo $pid?>"><input type="submit" id="submitDelete" class="btn btn-primary" value="Delete"></a>
				<?php
			}else{
				 ?>


				 <?php

				 } // end of isAdmin method
				  ?>

		    <h3><?php echo $p['first_name']." ".$p['last_name'];?></h3>
			<p><?php echo $p['commentText'];?></p>
			<sub><?php echo $p['date']; ?></sub>
		<br>


		<?php }?>
		</div>

		<?php }?>



</div>
<?php
if($u->isRegistered()){

	echo "<h3>".$username." comment: </h3>";

	?>

	<form action="http://corsair.cs.iupui.edu:21991/final/blog/<?php echo $task ?>" method="POST">
		<input type="hidden" name="uID" value="<?php echo $uID?>"/>
		<input type="hidden" name="pID" value="<?php echo $pID?>"/>
		<input type="hidden" name="date" value="<?php echo date("Y-m-d\TH:i:s",time()); ?>">


	    <textarea class="form-control" id="textComment" name="commentText" value="Comments." placeholder="What's on your mind?" rows="3" style="width:75%;"></textarea>
	<br>
	    <input type="submit" id="submitComment" class="btn btn-primary" value="Comment">

	</form>
</div>


<?php
}else{
?>

<h4>Login to post comments</h4>
<a href="http://corsair.cs.iupui.edu:20541/CIT313/SP2017/final/login" class="btn btn-primary">Login</a>
<br><br><br><br>
</div>
<?php
}
 ?>

<?php include('views/elements/footer.php');?>
