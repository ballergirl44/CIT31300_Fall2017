<?php
include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">

		<h1>Hayabusa Rider Blog</h1><hr/>
		<div class="bs-component">
									<div class="well">
										<h2>Whats new in Hayabusa riding</h2>
									</div>
								</div>

	<div class="jumbotron">
	<img src="https://i.pinimg.com/originals/94/6f/be/946fbe3af2f42fe69198cd7994c8001b.jpg" width="100%" class="img  no-repeat center center fixed center top">
	</div>
  </div>
  
</div>

<?php include('views/elements/footer.php');?>
