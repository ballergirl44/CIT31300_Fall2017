<?php

class BlogController extends Controller{

	public $postObject;

   // lets you see 1 post

   	public function post($pID){
			$this->set('post',$pID);
			$this->postObject = new Post();
			$post = $this->postObject->getPost($pID);
		  $this->set('post',$post);

			// add comment info here...
			$this->postObject = new Users();

			//fix issue for page
			$posts = $this->postObject->getAllUserComments();
			$this->set('posts',$posts);
			$this->set('username', $this->postObject->getUserName());

			$this->set('uid', $uID);
			$this->set('pid', $pID);

			//$this->set('title','dfgh');
			$this->set('textComment','');
			$this->set('pID','');
			$this->set('uID','');
			$this->set('userinfo',$_SESSION['uID']);

			// set task for adding comments
			$this->set('task','addc');
   	}


		public function addc(){
	    $this->set('title','');

				$this->postObject = new Post();

			$data = array(

	      'date'=>$_POST['date'],
	      'content'=>$_POST['commentText'],
				'uID'=>$_SESSION['uID'],
				'postID'=>$_POST['pID']
	      );
				$result = $this->postObject->addComment($data);
				$this->set('message', $result);
		}


	public function index(){

		$this->postObject = new Post();
		$posts = $this->postObject->getAllPosts();

		$this->set('post','');
		$this->set('title', 'Hayabusa Rider');
		$this->set('posts',$posts);

	}

}
