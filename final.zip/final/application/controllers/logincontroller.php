<?php

class LoginController extends Controller{

	protected $userobject;

	public function index(){

	}

	public function do_login(){
	 $this->userobject = new Users();
	 if($this->userobject->CheckUser($_POST['email'], $_POST['password'])){

		 $userInfo = $this->userobject->getUserFromEmail($_POST['email']);
		 $_SESSION['uID'] = $userInfo['uID'];

		 #redirect user to n page...
		 if(strlen($_SESSION['redirect'])  > 0 ){
		 	$view = $_SESSION['redirect'];
			unset($_SESSION['redirect']);
		  header('Location:' .BASE_URL.$view);
		}else{
			header('Location:' .BASE_URL);
		}
	 }else{
		 $this->set('error', 'Wrong password / email combo.');
	 }
	}


public function logout(){
	// unset session ID
	unset($_SESSION['uID']);
	// turn off session
	session_write_close();

	$logout_message = "<b>Successful Logout!</b>";
	header('Location: '.BASE_URL.'?logout_message='.$logout_message);


	}

}
