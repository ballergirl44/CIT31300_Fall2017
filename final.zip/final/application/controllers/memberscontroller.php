<?php

class MembersController extends Controller{

	public $postObject;
   // lets you see 1 post

   	public function users($uID){
		$this->set('posts',$uID);
		$this->postObject = new Users();
		$post = $this->postObject->getUsers($uID);
	  $this->set('post',$post);
		//$this->set('title', 'The Default Member View');

   	}

		public function index(){

	 		$this->postObject = new Users();
	 		$posts = $this->postObject->getAllUsers();
	 		$this->set('title', 'The Members View');
	 		$this->set('posts',$posts);

	 	}

}
