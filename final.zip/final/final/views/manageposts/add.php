<?php include('views/elements/header.php');?>


<div class="container">
	<h1><?php echo $PostTitle;?></h1>
	<div class="page-header">
  </div>
  <?php if($message){?>
    <div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert">×</button>
    	<?php echo $message?>
    </div>
  <?php }?>
  <div class="row">
      <div class="span8">
        <form action="<?php echo BASE_URL?>manageposts/<?php echo $task?>" method="post" onsubmit="editor.post()">
          <label>Title</label>
          <input type="text" class="span6" name="post_title" value="" required="title"><br>

					<label for="date">Date</label>
          <input type="date" id="date" size="16" name="post_date" class="span6" size="16" type="now" value="2017-03-11 16:20:18">

          <label for="category">Category</label>
          <select class="input-sm" name="post_categoryID" id="category" required="category">
          <option value="">-- Select Category --</option>

          <option value='1'>Tech</option>
					<option value='2'>Weather</option>
					<option value='3'>Sports</option>
					<option value='4'>Food</option>
					<option value='5'>Cars</option>
					<option value='6'>Computers</option>
					<option value='7'>TV Shows</option>
					<option value='8'>Science</option>
					<option value='9'>Futbol</option>
					<option value='10'>Housing</option>
					<option value='11'>Garage</option>
					<option value='12'>Diners</option>
				  </select>

     			<label for="content">Content</label>
          <textarea id="tinyeditor" name="post_content" style="width:556px;height: 200px"></textarea>
    			<br/>
          <input type="hidden" name="pID" value="<?php echo $pID?>"/>
          <button id="submit" type="submit" class="btn btn-primary" >Submit</button>
        </form>

      </div>
    </div>
</div>

<?php include('views/elements/footer.php');?>
